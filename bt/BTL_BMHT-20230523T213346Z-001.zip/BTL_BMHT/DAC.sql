--basic role for employee
create role emp_role;
grant connect to emp_role

--user giám đốc
create user director identified by director;
grant emp_role to director;
grant all privileges to director;

--role leader
create role leader;
grant emp_role to leader;
grant select on CHIETKHAU,GIAMH,MATHANG,KHACHHANG,KHACHHANGSI,TONKHODL,DONDATHANG,CHITIETDONDATHANG,PHIEUGIAO, CHITIETPHIEUIAO to leader
grant insert,update,delete on CHIETKHAU,GIAMH,MATHANG,KHACHHANG,KHACHHANGSI,TONKHODL,DONDATHANG,CHITIETDONDATHANG to leader;

--role sale_emp;
create role sale;
grant emp_role to sale;
grant select on KHACHHANG,KHACHHANGSI,TONKHODL,DONDATHANG,CHITIETDONDATHANG,PHIEUGIAO, CHITIETPHIEUIAO to sale;
grant insert,update,delete on KHACHHANG,KHACHHANGSI,TONKHODL,DONDATHANG,CHITIETDONDATHANG to sale;

--role customer;
create role customer;
grant select on MATHANG,GIAMH, KHACHHANG, KHACHHANGSI, DONDATHANG, CHITIETDONDATHANG to customer;

--role shiper;
create role shiper;
grant select on PHIEUGIAO, CHITIETPHIEUGIAO to shiper;
grant select on (MSKH,TenKH) on KHACHHANG to shiper;
grant select on (MSKH,SDT) on DIENTHOAIKH to shiper;
grant insert,update,delete on PHIEUGIAO, CHITIETPHIEUGIAO to shiper;
