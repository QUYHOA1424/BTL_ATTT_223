--<LOAD DATABASE>

--<CREATE USER>
--<btl_sec>
GRANT connect, create user, drop user,
create role, drop any role TO btl_sec IDENTIFIED BY btlsec;
--<btl_admin>
GRANT connect TO btl_admin IDENTIFIED BY btladmin;
<emp_role>
CREATE ROLE emp_role;
GRANT connect TO emp_role;
--<user>
-- Director A (Tổng Giám đốc)
CREATE USER directorA IDENTIFIED BY directorA; 
GRANT emp_role TO directorA;
-- Director B (Giám đốc điều hành)
CREATE USER directorB IDENTIFIED BY directorB; 
GRANT emp_role TO directorB;
-- Leader C (Trưởng phòng Sales phụ trách HCM)
CREATE USER leaderC IDENTIFIED BY leaderC; 
GRANT emp_role TO leaderC;
-- Emp D (Nhân viên thuộc phòng Sales phụ trách Đại lý HCM)
CREATE USER empD IDENTIFIED BY empD; 
GRANT emp_role TO empD;
--<>
CONN aldous/<pass>;
GRANT select ON aldous.khachhang TO emp_role;


--<Oracle OLS>

--<Step-1-Create_policy>
CONN lbacsys/lbacsys; 
BEGIN
  SA_SYSDBA.CREATE_POLICY (
  policy_name => 'ACCESS_KHACHHANG',
  column_name => 'OLS_COLUMN_2'); 
END; 
/

--<btl_admin manage components, lables,policy> 
GRANT access_khachhang_dba TO btl_admin;
-- Package dùng để tạo ra các thành phần của nhãn
GRANT execute ON sa_components TO btl_admin;
-- Package dùng để tạo các nhãn
GRANT execute ON sa_label_admin TO btl_admin;
-- Package dùng để gán chính sách cho các table/schema
GRANT execute ON sa_policy_admin TO btl_admin;

--<btl_sec manage user>
GRANT access_khachhang_dba TO btl_sec;
-- Package dùng để gán các label cho user
GRANT execute ON sa_user_admin TO btl_sec;

--<Step-2-Create_components>
--<creae-level>
CONN btl_admin/btladmin;
BEGIN
  sa_components.create_level 
	(policy_name => 'ACCESS_KHACHHANG', 
	long_name => 'TOPLIST', 
	short_name => 'TOP',
	level_num => 3000);
END;
/
EXECUTE sa_components.create_level ('ACCESS_KHACHHANG',2000,'MID','MIDLIST'); 
EXECUTE sa_components.create_level ('ACCESS_KHACHHANG',1000,'BOT','BOTLIST');
--<create-compartment>
BEGIN
  sa_components.create_compartment
	(policy_name => 'ACCESS_KHACHHANG',
	long_name => 'DAI LY',
	short_name => 'DL',
	comp_num => 2000);
END;
/ 
EXECUTE sa_components.create_compartment ('ACCESS_KHACHHANG',1000,'KS','KHACH SI');
--<create-group>
BEGIN
  sa_components.create_group
	(policy_name => 'ACCESS_KHACHHANG',
	long_name => 'CORPORATE',
	short_name => 'CORP',
	group_num => 10,
	parent_name => NULL);
END;
/
EXECUTE sa_components.create_group ('ACCESS_KHACHHANG',20,'HCM','HO CHI MINH','CORP');
EXECUTE sa_components.create_group ('ACCESS_KHACHHANG',30,'SCL','SONG CUU LONG','CORP');
EXECUTE sa_components.create_group ('ACCESS_KHACHHANG',40,'TBB','TAY BAC BO','CORP');
EXECUTE sa_components.create_group ('ACCESS_KHACHHANG',50,'BTB','BAC TRUNG BO','CORP');

<Step-3-create_data_label>
BEGIN
  sa_label_admin.create_label
	(policy_name => 'ACCESS_KHACHHANG',
	label_tag => 32020,
	label_value => 'TOP:DL:HCM');
END;
/
EXECUTE sa_label_admin.create_label ('ACCESS_KHACHHANG',31020,'TOP:KS:HCM');
EXECUTE sa_label_admin.create_label ('ACCESS_KHACHHANG',32030,'TOP:DL:SCL');
EXECUTE sa_label_admin.create_label ('ACCESS_KHACHHANG',31030,'TOP:KS:SCL');
EXECUTE sa_label_admin.create_label ('ACCESS_KHACHHANG',31040,'TOP:KS:TBB');
EXECUTE sa_label_admin.create_label ('ACCESS_KHACHHANG',31050,'TOP:KS:BTB');

--<Step-4-create_user_label>
--<by components>
CONN btl_sec/btlsec;
--levels
BEGIN
  sa_user_admin.set_levels
	(policy_name => 'ACCESS_KHACHHANG',
	user_name => 'EMPD',
	max_level => 'MID',
	min_level => 'BOT',
	def_level => 'MID',
	row_level => 'MID');
END;
/
--compartments
BEGIN
  sa_user_admin.set_compartments
	(policy_name => 'ACCESS_KHACHHANG',
	user_name => 'EMPD',
	read_comps => 'DL',
	write_comps => 'DL',
	def_comps => 'DL',
	row_comps => 'DL');
END;
/
--groups
BEGIN
  sa_user_admin.set_groups
	(policy_name => 'ACCESS_KHACHHANG',
	user_name => 'EMPD',
	read_groups => 'HCM',
	write_groups => 'HCM',
	def_groups => 'HCM',
	row_groups => 'HCM');
END;
/
--<by label>
BEGIN
  sa_user_admin.set_user_labels
	(policy_name => 'ACCESS_KHACHHANG',
	user_name => 'LEADERC',
	max_read_label => 'TOP:DL:HCM',
	max_write_label => 'TOP:DL:HCM',
	min_write_label => 'BOT',
	def_label => 'TOP:DL:HCM',
	row_label => 'TOP:DL:HCM');
END;
/
--<special privileges>
BEGIN
  sa_user_admin.set_user_privs
	(policy_name => 'ACCESS_KHACHHANG',
	user_name => 'DIRECTORA',
	PRIVILEGES => 'FULL');
END;
/

BEGIN
  sa_user_admin.set_user_privs
	(policy_name => 'ACCESS_KHACHHANG',
	user_name => 'DIRECTORB',
	PRIVILEGES => 'READ');
END;
/

--<step-5-apply_to_table_or_schema>
CONN btl_admin/btladmin;
BEGIN
  sa_policy_admin.apply_table_policy
	(policy_name => 'ACCESS_KHACHHANG',
	schema_name => 'ALDOUS',
	table_name => 'KHACHHANG',
	table_options => 'HIDE,NO_CONTROL');
END;
/
<--apply_label_to_data>
CONN aldous;
GRANT select, insert, update ON khachhang TO btl_admin;

CONN btl_admin/btladmin;
UPDATE aldous.khachhang SET ols_column_2 = char_to_label ('ACCESS_KHACHHANG', 'BOT');

UPDATE aldous.khachhang SET ols_column_2 = char_to_label ('ACCESS_KHACHHANG', 'TOP:DL:SCL')
WHERE KHS='NO' and MSKV = 'SCL';
UPDATE aldous.khachhang SET ols_column_2 = char_to_label ('ACCESS_KHACHHANG', 'TOP:KS:TBB')
WHERE KHS='YES' and MSKV = 'TBB';
UPDATE aldous.khachhang SET ols_column_2 = char_to_label ('ACCESS_KHACHHANG', 'TOP:KS:BTB')
WHERE KHS='YES' and MSKV = 'BTB';
UPDATE aldous.khachhang SET ols_column_2 = char_to_label ('ACCESS_KHACHHANG', 'TOP:KS:HCM')
WHERE KHS='YES' and MSKV = 'HCM';
UPDATE aldous.khachhang SET ols_column_2 = char_to_label ('ACCESS_KHACHHANG', 'TOP:KS:SCL')
WHERE KHS='YES' and MSKV = 'SCL';


COMMIT ;

--<active-policy>
CONN btl_admin/btladmin;
BEGIN
  sa_policy_admin.remove_table_policy
	(policy_name => 'ACCESS_KHACHHANG',
	schema_name => 'ALDOUS',
	table_name => 'KHACHHANG');

  sa_policy_admin.apply_table_policy
	(policy_name => 'ACCESS_KHACHHANG',
	schema_name => 'ALDOUS',
	table_name => 'KHACHHANG',
	table_options => 'HIDE,READ_CONTROL,WRITE_CONTROL,CHECK_CONTROL');
END;
/

